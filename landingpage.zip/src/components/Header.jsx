


import React from 'react';



const Header = () => {

  return (
    <div className="relative bg-white">
      <div className="container max-w-[1400px] w-full mx-auto px-3">
       <div className="flex py-3 justify-center items-center w-full">
          {/* <img src={mike} alt="Logo"  /> */}
<h1>🎙 Welcome to EchoWrite</h1>
    </div>
    </div>
    </div>
  );
};

export default Header;

